import java.util.Random;
public class Tast05 {

    public static boolean isPrime(int num) {
        if (num <= 1) 
        return false;

        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) 
            return false;
        }

        return true;
    }
    public static int generateRandomPrime(int min, int max) {
        Random rand = new Random();

        while (true) {
            int randomNum = rand.nextInt(max - min + 1) + min;

            if (isPrime(randomNum)) {
                return randomNum;
            }
        }
    }

    public static void main(String[] args) {
        int min = 10;
        int max = 20;

        int prime = generateRandomPrime(min, max);
        System.out.println("Random Prime Number between " + min + " and " + max + ": " + prime);
    }
}
