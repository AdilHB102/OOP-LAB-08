public class Task01{
    public String  reverseString(String str) {
        String reversed = "";
        for (int i = str.length()-1; i > 0; i--) {
            reversed += str.charAt(i);
        }
        return reversed;
    }

    public static void main(String[] args) {
        ReverseStringExample r = new ReverseStringExample();
        String input = "hello";

        String result = r.reverseString(input);
        System.out.println("Input :"+input);
        System.out.println("Reversed: "+result);

    }
}
