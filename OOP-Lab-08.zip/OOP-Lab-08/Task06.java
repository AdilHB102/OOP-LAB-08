import java.util.Random;

public class Tast06 {

    public static void main(String[] args) {

        int[] freq = new int[21];

        Random rand = new Random();
        for (int i = 0; i < 100; i++) {
            int num = rand.nextInt(21);
            freq[num]++;
        }
        for (int i = 0; i <= 20; i++) {
            System.out.println("Number " + i + ": " + freq[i] + " times");
        }
    }
}
