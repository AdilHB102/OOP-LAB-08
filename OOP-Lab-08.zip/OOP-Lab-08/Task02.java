public class Task02 {

    public static boolean isPalindrome(String str) {
        String cleanStr = "";
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (Character.isLetterOrDigit(ch)) {
                cleanStr += Character.toLowerCase(ch);
            }
        }

        String reversed = "";
        for (int i = cleanStr.length() - 1; i >= 0; i--) {
            reversed += cleanStr.charAt(i);
        }

        return cleanStr.equals(reversed);
    }

    public static void main(String[] args) {
        String input = "A man, a plan, a canal: Panama";

        boolean result = isPalindrome(input);
        System.out.println("Is Palindrome? " + result);
    }
}
